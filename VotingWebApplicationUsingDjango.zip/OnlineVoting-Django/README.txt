Voting web application using Django framework
